#!/bin/bash
# 获取 eth0 网卡的 IP 地址
ip addr show eth0 | grep 'inet ' | awk '{print $2}' | cut -d/ -f1
