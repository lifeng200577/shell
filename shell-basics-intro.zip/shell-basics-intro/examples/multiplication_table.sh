#!/bin/bash
for i in `seq 9`
do
    for j in `seq $i`
    do
        printf "$j*$i=%2d " $((j*i))
    done
    echo ""
done
