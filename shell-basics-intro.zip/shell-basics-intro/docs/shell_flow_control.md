# Shell 流程控制

示例：

```bash
if [ $1 -gt 0 ]; then
    echo "正数"
else
    echo "非正数"
fi
```
