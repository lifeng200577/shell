# Shell 脚本基础知识入门

本项目整理自 CSDN 作者 [lifeng4321](https://blog.csdn.net/lifeng4321/article/details/143232836) 的文章，内容涵盖 Shell 基础命令、变量、流程控制、函数等。

## 项目结构

- `README.md`: 项目说明文档
- `examples/`: 示例脚本
- `scripts/`: 常用脚本封装
- `docs/`: 拓展文档

## 快速开始

```bash
cd examples
bash multiplication_table.sh
```

